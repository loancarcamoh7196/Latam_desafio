#h = { :claveuno => 10, :clavedos => 20, :clavetres => 30 }
h = { 'claveuno': 10, 'clavedos': 20, 'clavetres': 30 }
