def saludo(nombre)
  puts 'Hola mundo' if nombre == 'Hola'
end

saludo('Hola')
saludo('nn')
