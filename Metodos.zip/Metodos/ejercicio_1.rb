def par(x)
  x.even? 
end
puts par(2)
puts par(3)
puts par(4)
puts par(5)
