def check5(n)
  n >5 ? true:false
end


puts check5(5) # Debería ser false
puts check5(6) # Debería ser true
