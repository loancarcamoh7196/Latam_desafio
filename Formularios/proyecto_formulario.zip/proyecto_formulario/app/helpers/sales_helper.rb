module SalesHelper
end
