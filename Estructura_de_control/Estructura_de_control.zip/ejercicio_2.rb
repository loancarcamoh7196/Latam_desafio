a = 5
if a == 5
puts 'La condición es verdadera.'
end
