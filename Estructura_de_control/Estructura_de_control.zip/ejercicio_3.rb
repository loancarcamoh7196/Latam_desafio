a = 'X9-by'

puts 'HOLA!' if a == 'X9-by'
