a = true
b = false
if a
  puts ':)'
else
    puts (b ? ':|' : ':(')
end
