a = true
b = true
if a
  puts (b ? 'Lograste A y B!' : 'Lograste A! Pero no B!')
else
  puts 'No lograste A ni B!'
end
