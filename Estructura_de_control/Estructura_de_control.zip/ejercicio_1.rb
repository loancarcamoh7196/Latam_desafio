a = 2
if a == 2
puts 'La condición es verdadera.'
end
